#!/usr/bin/env python3

#000000 (Black)
#E69F00 (Orange)
#56B4E9 (Sky blue)
#009E73 (Bluish green)
#D55E00 (Vermilion)
#F0E442 (Yellow)
#0072B2 (Blue)
#CC79A7 (Reddish purple)

import sys
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as colors
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from mpl_toolkits.axes_grid1 import make_axes_locatable

plt.rc('patch',linewidth=2)
plt.rc('axes', linewidth=2, labelpad=10)
plt.rc('xtick.minor', size=4, width=2)
plt.rc('xtick.major', size=8, width=2, pad=8)
plt.rc('ytick.minor', size=4, width=2)
plt.rc('ytick.major', size=8, width=2, pad=8)
plt.rc('text', usetex=True)
plt.rc('font', family='serif', serif='Computer Modern', size=30)

filename=sys.argv[1]

# INPUT
print('Reading...')
f=open(filename+'.dat','r')
line=f.readline()
field=line.split()
hashtag=field[0]
lx=int(field[1])
ly=int(field[2])
m=int(field[3])
ncol=lx
nrow=ly
hei=-np.ones((nrow,ncol))

for line in f:
	field=line.split()
	
	i=int(field[0])
	j=int(field[1])
	
	hei[j,i]=float(field[2])
f.close()
# INPUT

print('Ploting...')
xbox=10
ybox=int(xbox*(float(ly)/float(lx)))
fig,ax=plt.subplots(figsize=(xbox,ybox),dpi=300)

#palette=plt.cm.viridis
palette=plt.cm.inferno
palette.set_over('#666666',alpha=1.0)
palette.set_under('#FFFFFF',alpha=1.0)
#vmin=hei.min()
#vmax=hei.max()

mylist=sorted(list(np.unique(hei)))
vmin=mylist[0]
vmax=mylist[-1]

myplot=plt.imshow(hei,cmap=palette,interpolation='none',norm=colors.Normalize(vmin=vmin,vmax=vmax,clip=False))
myplot.axes.get_xaxis().set_visible(False)
myplot.axes.get_yaxis().set_visible(False)
plt.axis('off')

divider=make_axes_locatable(ax)
cax=divider.append_axes('right', size='5%', pad=0.5)
cbar=plt.colorbar(myplot,cax=cax)

annotate='FBM'
ax.annotate(annotate,xy=(0.05, 0.05),xycoords='axes fraction',horizontalalignment='left',verticalalignment='bottom',color='white')

plt.savefig(filename+'.pdf', bbox_inches='tight')
