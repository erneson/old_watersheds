#!/bin/bash

L=2048
nsam=100

gfortran -O3 -o fbm2d fbm2d.f90

i=1
for h in -1.0 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0;do
	for j in $(seq 1 $nsam);do
		s=123$(printf "%02d" $i)$(printf "%04d" $j)
		
		l=$(printf "%04d" $(expr $L / 2))
		
		./fbm2d $L $h $s l"$l"_h"$h"_s"$s"
		#./fbm2d.py fbm2d_l"$l"_h"$h"_s"$s"
	done
	i=$(expr $i + 1)
done
