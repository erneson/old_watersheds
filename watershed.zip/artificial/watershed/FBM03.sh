#!/bin/bash

#gcc -fopenmp -lm -O3 -o watershed watershed.c

nthreads=4
hcutoff=0.0
filename1='FBM'

nsam=100

i=3
h=0.1

for j in $(seq 1 $nsam);do
	s=123$(printf "%02d" $i)$(printf "%04d" $j)
	
	filename2='fbm2d_l1024_h'$h'_s'$s
	
	(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> d.dat
done
