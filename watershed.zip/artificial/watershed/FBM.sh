#!/bin/bash

gcc -fopenmp -lm -O3 -o watershed watershed.c

nthreads=4
hcutoff=0.0
filename1='FBM'
filename2='fbm2d_l1024_h-1.0_s1230001'

./watershed.sh $nthreads $hcutoff $filename1 $filename2
