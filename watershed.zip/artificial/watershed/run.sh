#!/bin/bash

./RANDOM.sh &
./FBM01.sh
./FBM02.sh &
./FBM03.sh
./FBM04.sh &
./FBM05.sh
./FBM06.sh &
./FBM07.sh
./FBM08.sh &
./FBM09.sh
./FBM10.sh &
./FBM11.sh
./FBM12.sh &
