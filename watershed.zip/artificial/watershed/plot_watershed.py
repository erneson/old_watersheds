#!/usr/bin/env python3

import sys
import numpy as np
import math
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import random as rand

plt.rc('patch',linewidth=2)
plt.rc('axes', linewidth=2, labelpad=10)
plt.rc('xtick.minor', size=4, width=2)
plt.rc('xtick.major', size=8, width=2, pad=8)
plt.rc('ytick.minor', size=4, width=2)
plt.rc('ytick.major', size=8, width=2, pad=8)
plt.rc('text', usetex=True)
plt.rc('font', family='serif', serif='Computer Modern', size=30)

name1=sys.argv[1]
name2=sys.argv[2]

print('Ploting...')

f=open('results/'+name1+'/sigma_'+name2+'.dat','r')
line=f.readline()
field=line.split()
hashtag=field[0]
lx=int(field[1])
ly=int(field[2])
n=lx*ly
m=int(field[3])

ncol=lx
nrow=ly
sig=-2*np.ones((nrow,ncol))

for line in f:
	field=line.split()
	
	i=int(field[0])
	j=int(field[1])
	
	sig[j,i]=int(field[2])
f.close()

xbox=10
ybox=int(xbox*(float(ly)/float(lx)))
fig,ax=plt.subplots(figsize=(xbox,ybox),dpi=300)

rand.seed(123)
mycolors = [(0.1,0.1,0.1)]+[(0.2+0.8*rand.random(),0.2+0.8*rand.random(),0.2+0.8*rand.random()) for i in range(n)] # 1+n colors
mymap = mpl.colors.LinearSegmentedColormap.from_list('mymap', mycolors, N=1+n)

myplot=plt.imshow(sig,cmap=mymap,interpolation='none')
myplot.axes.get_xaxis().set_visible(False)
myplot.axes.get_yaxis().set_visible(False)
plt.axis('off')

annotate='Watersheds'
ax.annotate(annotate,xy=(0.05, 0.05),xycoords='axes fraction',horizontalalignment='left',verticalalignment='bottom')

plt.savefig('results/'+name1+'/sigma_'+name2+'.pdf', bbox_inches='tight')
