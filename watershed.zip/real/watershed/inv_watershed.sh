#!/bin/bash

nthreads=$1
hcutoff=$2
filename1=$3
filename2=$4

mkdir -p results/inv_"$filename1"

./inv_watershed "$nthreads" "$hcutoff" "$filename1" "$filename2"
