#!/bin/bash

#gcc -fopenmp -lm -O3 -o watershed watershed.c

nthreads=4
hcutoff=0.0
filename1='GEBCO'
filename2='GEBCO_2014_2D_90N_90S_f8'
(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> a.dat

#nthreads=4
#hcutoff=0.0
#filename1='GEBCO'
#filename2='GEBCO_2014_2D_90N_90S_f4'
#(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> a.dat

#nthreads=4
#hcutoff=0.0
#filename1='GEBCO'
#filename2='GEBCO_2014_2D_90N_90S_f2'
#(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> a.dat

#nthreads=4
#hcutoff=0.0
#filename1='GEBCO'
#filename2='GEBCO_2014_2D_90N_90S_f1'
#(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> a.dat
