#!/bin/bash

./GEBCO.sh &
./inv_GEBCO.sh
./LOLA.sh &
./inv_LOLA.sh
./MOLA.sh &
./inv_MOLA.sh
