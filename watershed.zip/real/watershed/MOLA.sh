#!/bin/bash

#gcc -fopenmp -lm -O3 -o watershed watershed.c

nthreads=4
hcutoff=0.0
filename1='MOLA'
filename2='Mars_MGS_MOLA_DEM_mosaic_global_463m_90N_90S_f8'
(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> c.dat

#nthreads=4
#hcutoff=0.0
#filename1='MOLA'
#filename2='Mars_MGS_MOLA_DEM_mosaic_global_463m_90N_90S_f4'
#(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> c.dat

#nthreads=4
#hcutoff=0.0
#filename1='MOLA'
#filename2='Mars_MGS_MOLA_DEM_mosaic_global_463m_90N_90S_f2'
#(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> c.dat

#nthreads=4
#hcutoff=0.0
#filename1='MOLA'
#filename2='Mars_MGS_MOLA_DEM_mosaic_global_463m_90N_90S_f1'
#(time ./watershed.sh $nthreads $hcutoff $filename1 $filename2) 2>> c.dat
