#include <stdio.h>
#include <limits.h>
#include <float.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <omp.h>

#include <sys/stat.h>
#include <sys/types.h>

struct site_lattice
{
	int lx;
	int ly;
	int n;
	int m;
	double lon0;
	double lat0;
	double delta;
	double R;
	
	float *h;
	int *sigma;
	int *basin;
};

struct site_neighborhood
{
	int NNZV; // Compressed Row "Binary" Storage (CRBS)
	int *IV; // Compressed Row "Binary" Storage (CRBS)
	int *JV; // Compressed Row "Binary" Storage (CRBS)
	
	int NNZM; // Compressed Row "Binary" Storage (CRBS)
	int *IM;// Compressed Row "Binary" Storage (CRBS)
	int *JM; // Compressed Row "Binary" Storage (CRBS)
};

struct normal_list
{
	int n;
	int m;
	int *val;
	int *lav;
};

struct binary_heap
{
	int n;
	int m;
	int *ind;
	float *val;
};

void input(float hcutoff,char name1[100],char name2[100],struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land);

void coastline(struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land,struct normal_list *coast);
void drainage_basin(int nthreads,struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *coast);
void invasion_percolation(struct binary_heap *heap,struct site_lattice *sl,struct site_neighborhood *nei,int *status,int k);
void burning(struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land);

void output(struct site_lattice *sl,struct normal_list *land,char name1[100],char name2[100]);

void add_to_list(struct normal_list *list,int k);
void remove_from_list(struct normal_list *list,int k);

int parent(int i);
int left(int i);
int right(int i);
void min_heap_insert(struct binary_heap *Heap,float val_key,int key);
void heap_decrease_key(struct binary_heap *Heap,float val_key,int key);
int heap_extract_min(struct binary_heap *Heap);
void min_heapify(struct binary_heap *Heap,int i);
void max_heap_insert(struct binary_heap *heap,float val_key,int key);
void heap_increase_key(struct binary_heap *heap,float val_key,int key);
int heap_extract_max(struct binary_heap *heap);
void max_heapify(struct binary_heap *heap,int i);

int main(int argc,char *argv[])
{
	int nthreads;
	float hcutoff;
	char name1[100];
	char name2[100];
	
	struct site_neighborhood *nei;
	
	struct site_lattice *sl;
	struct normal_list *land;
	struct normal_list *coast;
	
	int i,j,k;
	int u,v,w;
	
	/*/////////*/
	/*WATERSHED*/
	/*/////////*/
	nthreads=atoi(argv[1]);
	hcutoff=atof(argv[2]);
	strcpy(name1,argv[3]);
	strcpy(name2,argv[4]);
	
	/*INPUT*/
	nei=(struct site_neighborhood *)malloc(sizeof(struct site_neighborhood));
	sl=(struct site_lattice *)malloc(sizeof(struct site_lattice));
	land=(struct normal_list *)malloc(sizeof(struct normal_list));
	input(hcutoff,name1,name2,sl,nei,land);
	/*INPUT*/
	
	/*COASTLINE*/
	coast=(struct normal_list *)malloc(sizeof(struct normal_list));
	coastline(sl,nei,land,coast);
	/*COASTLINE*/
	
	/*DRAINAGE_BASIN*/
	drainage_basin(nthreads,sl,nei,coast);
	/*DRAINAGE_BASIN*/
	
	/*BURNING*/
	burning(sl,nei,land);
	/*BURNING*/
	
	/*OUTPUT*/
	output(sl,land,name1,name2);
	/*OUTPUT*/
	
	free(coast->lav);
	free(coast->val);
	free(coast);
	
	free(land->lav);
	free(land->val);
	free(land);
	
	free(sl->basin);
	free(sl->sigma);
	free(sl->h);
	free(sl);
	
	free(nei->JM);
	free(nei->IM);
	free(nei->JV);
	free(nei->IV);
	
	/*/////////*/
	/*WATERSHED*/
	/*/////////*/
	
	return(0);
}

void input(float hcutoff,char name1[100],char name2[100],struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land)
{
	char filename[400];
	FILE *f;
	char hashtag;
	int lx,ly;
	int m;
	double lon0,lat0;
	double delta;
	double R;
	
	float height;
	
	int i,j,k;
	int r,s,t;
	int w;
	
/*	printf("INPUT\n");*/
	
	strcpy(filename,"../datasets/");
	strcat(filename,name1);
	strcat(filename,"/");
	strcat(filename,name2);
	strcat(filename,".dat");
	f=fopen(filename,"r");
	fscanf(f,"%c %d %d %d %lf %lf %lf %lf\n",&hashtag,&lx,&ly,&m,&lon0,&lat0,&delta,&R);
	
	/*SETTING_UP*/
	sl->lx=lx;
	sl->ly=ly;
	sl->n=sl->lx*sl->ly;
	sl->m=m;
	sl->lon0=lon0;
	sl->lat0=lat0;
	sl->delta=delta;
	sl->R=R;
	sl->h=(float *)malloc(sl->n*sizeof(float));
	sl->sigma=(int *)malloc(sl->n*sizeof(int));
	sl->basin=(int *)malloc(sl->n*sizeof(int));
	land->n=sl->n;
	land->m=0;
	land->val=(int *)malloc(sl->n*sizeof(int));
	land->lav=(int *)malloc(sl->n*sizeof(int));
	/*PBC*/
	nei->NNZV=2*sl->lx*(sl->lx+2*sl->ly-4);
	nei->IV=(int *)malloc((sl->n+1)*sizeof(int));
	nei->JV=(int *)malloc(nei->NNZV*sizeof(int));
	nei->NNZM=2*sl->lx*(sl->lx+4*sl->ly-6);
	nei->IM=(int *)malloc((sl->n+1)*sizeof(int));
	nei->JM=(int *)malloc(nei->NNZM*sizeof(int));
	/*PBC*/
	
	for(i=0;i<sl->n;i++)
	{
		sl->h[i]=-2.;
		sl->sigma[i]=-2;
		sl->basin[i]=-2;
		
		land->val[i]=-2;
		land->lav[i]=-2;
	}
	/*PBC*/
	for(i=0;i<sl->n+1;i++)
	{
		nei->IV[i]=-2;
		nei->IM[i]=-2;
	}
	for(i=0;i<nei->NNZV;i++)
	{
		nei->JV[i]=-2;
	}
	for(i=0;i<nei->NNZM;i++)
	{
		nei->JM[i]=-2;
	}
	/*PBC*/
	/*SETTING_UP*/
	
	/*PBC*/
	t=0;
	w=0;
	nei->IV[0]=t;
	nei->IM[0]=w;
	for(k=0;k<sl->n;k++)
	{
		i=k%sl->lx;
		j=k/sl->lx;
		
		if(j==0)
		{
			if(i==0)
			{
				/*VON NEUMMAN*/
				nei->JV[t]=k+1;
				t=t+1;
				for(r=0;r<sl->lx;r++)
				{
					s=r;
					
					if(s!=k+sl->lx-1 && s!=k && s!=k+1)
					{
						nei->JV[t]=s; // PBC
						t=t+1;
					}
				}
				nei->JV[t]=k+sl->lx-1; // PBC
				t=t+1;
				nei->JV[t]=k+sl->lx;
				t=t+1;
				
				nei->IV[k+1]=t;
				/*VON NEUMMAN*/
				
				/*MOORE*/
				nei->JM[w]=k+1;
				w=w+1;
				for(r=0;r<sl->lx;r++)
				{
					s=r;
					
					if(s!=k+sl->lx-1 && s!=k && s!=k+1)
					{
						nei->JM[w]=s; // PBC
						w=w+1;
					}
				}
				nei->JM[w]=k+sl->lx-1; // PBC
				w=w+1;
				nei->JM[w]=k+sl->lx;
				w=w+1;
				nei->JM[w]=k+1+sl->lx;
				w=w+1;
				nei->JM[w]=k+2*sl->lx-1; // PBC
				w=w+1;
				
				nei->IM[k+1]=w;
				/*MOORE*/
			}
			else
			{
				if(i==sl->lx-1)
				{
					/*VON NEUMMAN*/
					nei->JV[t]=k-sl->lx+1; // PBC
					t=t+1;
					for(r=0;r<sl->lx;r++)
					{
						s=r;
						
						if(s!=k-1 && s!=k && s!=k-sl->lx+1)
						{
							nei->JV[t]=s; // PBC
							t=t+1;
						}
					}
					nei->JV[t]=k-1;
					t=t+1;
					nei->JV[t]=k+sl->lx;
					t=t+1;
					
					nei->IV[k+1]=t;
					/*VON NEUMMAN*/
					
					/*MOORE*/
					nei->JM[w]=k-sl->lx+1; // PBC
					w=w+1;
					for(r=0;r<sl->lx;r++)
					{
						s=r;
						
						if(s!=k-1 && s!=k && s!=k-sl->lx+1)
						{
							nei->JM[w]=s; // PBC
							w=w+1;
						}
					}
					nei->JM[w]=k-1;
					w=w+1;
					nei->JM[w]=k+1; // PBC
					w=w+1;
					nei->JM[w]=k-1+sl->lx;
					w=w+1;
					nei->JM[w]=k+sl->lx;
					w=w+1;
					
					nei->IM[k+1]=w;
					/*MOORE*/
				}
				else
				{
					/*VON NEUMMAN*/
					for(r=0;r<sl->lx;r++)
					{
						s=r;
						
						if(s!=k-1 && s!=k && s!=k+1)
						{
							nei->JV[t]=s; // PBC
							t=t+1;
						}
						else
						{
							if(s==k-1)
							{
								nei->JV[t]=s;
								t=t+1;
							}
							
							if(s==k+1)
							{
								nei->JV[t]=s;
								t=t+1;
							}
						}
					}
					nei->JV[t]=k+sl->lx;
					t=t+1;
					
					nei->IV[k+1]=t;
					/*VON NEUMMAN*/
					
					/*MOORE*/
					for(r=0;r<sl->lx;r++)
					{
						s=r;
						
						if(s!=k-1 && s!=k && s!=k+1)
						{
							nei->JM[w]=s; // PBC
							w=w+1;
						}
						else
						{
							if(s==k-1)
							{
								nei->JM[t]=s;
								w=w+1;
							}
							
							if(s==k+1)
							{
								nei->JM[t]=s;
								w=w+1;
							}
						}
					}
					nei->JM[w]=k-1+sl->lx;
					w=w+1;
					nei->JM[w]=k+sl->lx;
					w=w+1;
					nei->JM[w]=k+1+sl->lx;
					w=w+1;
					
					nei->IM[k+1]=w;
					/*MOORE*/
				}
			}
		}
		else
		{
			if(j<sl->ly-1) //k<=(sl->ly-1)*sl->lx-1
			{
				if(i==0)
				{
					/*VON NEUMMAN*/
					nei->JV[t]=k-sl->lx;
					t=t+1;
					nei->JV[t]=k+1;
					t=t+1;
					nei->JV[t]=k-1+sl->lx; // PBC
					t=t+1;
					nei->JV[t]=k+sl->lx;
					t=t+1;
					
					nei->IV[k+1]=t;
					/*VON NEUMMAN*/
					
					/*MOORE*/
					nei->JM[w]=k-sl->lx;
					w=w+1;
					nei->JM[w]=k+1-sl->lx; //PBC
					w=w+1;
					nei->JM[w]=k-1;
					w=w+1;
					nei->JM[w]=k+1;
					w=w+1;
					nei->JM[w]=k-1+sl->lx; // PBC
					w=w+1;
					nei->JM[w]=k+sl->lx;
					w=w+1;
					nei->JM[w]=k+1+sl->lx;
					w=w+1;
					nei->JM[w]=k-1+2*sl->lx; // PBC
					w=w+1;
					
					nei->IM[k+1]=w;
					/*MOORE*/
				}
				else
				{
					if(i==sl->lx-1)
					{
						/*VON NEUMMAN*/
						nei->JV[t]=k-sl->lx;
						t=t+1;
						nei->JV[t]=k-sl->lx+1; // PBC
						t=t+1;
						nei->JV[t]=k-1;
						t=t+1;
						nei->JV[t]=k+sl->lx;
						t=t+1;
						
						nei->IV[k+1]=t;
						/*VON NEUMMAN*/
						
						/*MOORE*/
						nei->JM[w]=k-2*sl->lx+1; // PBC
						w=w+1;
						nei->JM[w]=k-1-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx+1; // PBC
						w=w+1;
						nei->JM[w]=k-1;
						w=w+1;
						nei->JM[w]=k+1; // PBC
						w=w+1;
						nei->JM[w]=k-1+sl->lx;
						w=w+1;
						nei->JM[w]=k+sl->lx;
						w=w+1;
						
						nei->IM[k+1]=w;
						/*MOORE*/
					}
					else
					{
						/*VON NEUMMAN*/
						nei->JV[t]=k-sl->lx;
						t=t+1;
						nei->JV[t]=k-1;
						t=t+1;
						nei->JV[t]=k+1;
						t=t+1;
						nei->JV[t]=k+sl->lx;
						t=t+1;
						
						nei->IV[k+1]=t;
						/*VON NEUMMAN*/
						
						/*MOORE*/
						nei->JM[w]=k-1-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx;
						w=w+1;
						nei->JM[w]=k+1-sl->lx;
						w=w+1;
						nei->JM[w]=k-1;
						w=w+1;
						nei->JM[w]=k+1;
						w=w+1;
						nei->JM[w]=k-1+sl->lx;
						w=w+1;
						nei->JM[w]=k+sl->lx;
						w=w+1;
						nei->JM[w]=k+1+sl->lx;
						w=w+1;
						
						nei->IM[k+1]=w;
						/*MOORE*/
					}
				}
			}
			else
			{
				if(i==0)
				{
					/*VON NEUMMAN*/
					nei->JV[t]=k-sl->lx;
					t=t+1;
					nei->JV[t]=k+1;
					t=t+1;
					for(r=0;r<sl->lx;r++)
					{
						s=r+(sl->ly-1)*sl->lx;
						
						if(s!=k-1+sl->lx && s!=k && s!=k+1)
						{
							nei->JV[t]=s; // PBC
							t=t+1;
						}
					}
					nei->JV[t]=k-1+sl->lx; // PBC
					t=t+1;
					
					nei->IV[k+1]=t;
					/*VON NEUMMAN*/
					
					/*MOORE*/
					nei->JM[w]=k-sl->lx;
					w=w+1;
					nei->JM[w]=k+1-sl->lx;
					w=w+1;
					nei->JM[w]=k-1; // PBC
					w=w+1;
					nei->JM[w]=k+1;
					w=w+1;
					for(r=0;r<sl->lx;r++)
					{
						s=r+(sl->ly-1)*sl->lx;
						
						if(s!=k-1+sl->lx && s!=k && s!=k+1)
						{
							nei->JM[w]=s; // PBC
							w=w+1;
						}
					}
					nei->JM[w]=k-1+sl->lx; // PBC
					w=w+1;
					
					nei->IM[k+1]=w;
					/*MOORE*/
				}
				else
				{
					if(i==sl->lx-1)
					{
						/*VON NEUMMAN*/
						nei->JV[t]=k-sl->lx;
						t=t+1;
						nei->JV[t]=k-sl->lx+1; // PBC
						t=t+1;						
						for(r=0;r<sl->lx;r++)
						{
							s=r+(sl->ly-1)*sl->lx;
							
							if(s!=k-1 && s!=k && s!=k-sl->lx+1)
							{
								nei->JV[t]=s; // PBC
								t=t+1;
							}
						}
						nei->JV[t]=k-1;
						t=t+1;
						
						nei->IV[k+1]=t;
						/*VON NEUMMAN*/
						
						/*MOORE*/
						nei->JM[w]=k-2*sl->lx+1; // PBC
						w=w+1;
						nei->JM[w]=k-1-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx+1; // PBC
						w=w+1;
						for(r=0;r<sl->lx;r++)
						{
							s=r+(sl->ly-1)*sl->lx;
							
							if(s!=k-1 && s!=k && s!=k-sl->lx+1)
							{
								nei->JM[w]=s; // PBC
								w=w+1;
							}
						}
						nei->JM[w]=k-1;
						w=w+1;
						
						nei->IM[k+1]=w;
						/*MOORE*/
					}
					else
					{
						/*VON NEUMMAN*/
						nei->JV[t]=k-sl->lx;
						t=t+1;
						for(r=0;r<sl->lx;r++)
						{
							s=r+(sl->ly-1)*sl->lx;
							
							if(s!=k-1 && s!=k && s!=k+1)
							{
								nei->JV[t]=s; // PBC
								t=t+1;
							}
							else
							{
								if(s==k-1)
								{
									nei->JV[t]=s;
									t=t+1;
								}
								
								if(s==k+1)
								{
									nei->JV[t]=s;
									t=t+1;
								}
							}
						}
						
						nei->IV[k+1]=t;
						/*VON NEUMMAN*/
						
						/*MOORE*/
						nei->JM[w]=k-1-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx;
						w=w+1;
						nei->JM[w]=k+1-sl->lx;
						w=w+1;
						for(r=0;r<sl->lx;r++)
						{
							s=r+(sl->ly-1)*sl->lx;
							
							if(s!=k-1 && s!=k && s!=k+1)
							{
								nei->JM[w]=s; // PBC
								w=w+1;
							}
							else
							{
								if(s==k-1)
								{
									nei->JM[w]=s;
									w=w+1;
								}
								
								if(s==k+1)
								{
									nei->JM[w]=s;
									w=w+1;
								}
							}
						}
						
						nei->IM[k+1]=w;
						/*MOORE*/
					}
				}
			}
		}
	}
	/*PBC*/
	
	srand(123); // Seed of the random function
	for(r=0;r<sl->m;r++)
	{
		fscanf(f,"%d %d %f\n",&i,&j,&height);
		k=i+j*sl->lx;
		
		height=height+0.1*(float)rand()/(float)RAND_MAX; //To avoid sites of exactly the same height
		
		sl->h[k]=height;
		
		if(sl->h[k]>hcutoff)
		{
			add_to_list(land,k);
			
			sl->sigma[k]=-1;
		}
	}
	fclose(f);
}

void coastline(struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land,struct normal_list *coast)
{
	int i,k;
	int r,s;
	
/*	printf("COAST\n");*/
	
	/*SETTING_UP*/
	coast->n=sl->n;
	coast->m=0;
	coast->val=(int *)malloc(coast->n*sizeof(int));
	coast->lav=(int *)malloc(coast->n*sizeof(int));
	for(i=0;i<coast->n;i++)
	{
		coast->val[i]=-2;
		coast->lav[i]=-2;
	}
	/*SETTING_UP*/
	
	for(i=0;i<land->m;i++)
	{
		k=land->val[i];
		
		for(r=nei->IV[k];r<nei->IV[k+1];r++) // from IA[i] to IA[i+1]-1
		{
			s=nei->JV[r];
			
			if(sl->sigma[s]==-2)
			{
				add_to_list(coast,k);
			}
		}
	}
}

void drainage_basin(int nthreads,struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *coast)
{
	int **check;
	int **status;
	struct normal_list *stalker;
	struct binary_heap *heap;
	
	int i,j,k;
	int r,s,t;
	int u,v;
	
	int ithread;
	
/*	printf("DRAINAGE_BASIN\n");*/
	
	/*OPENMP*/
	omp_set_dynamic(0);
	omp_set_num_threads(nthreads);
	/*OPENMP*/
	
	/*SETTING_UP*/
	check=(int **)malloc(nthreads*sizeof(int *));
	status=(int **)malloc(nthreads*sizeof(int *));
	stalker=(struct normal_list *)malloc(nthreads*sizeof(struct normal_list));
	heap=(struct binary_heap *)malloc(nthreads*sizeof(struct binary_heap));
	for(i=0;i<nthreads;i++)
	{
		check[i]=(int *)malloc(sl->n*sizeof(int));
		status[i]=(int *)malloc(sl->n*sizeof(int));
		
		stalker[i].val=(int *)malloc(sl->n*sizeof(int));
		stalker[i].lav=(int *)malloc(sl->n*sizeof(int));
		
		heap[i].ind=(int *)malloc(sl->n*sizeof(int));
		heap[i].val=(float *)malloc(sl->n*sizeof(float));
	}
	/*SETTING_UP*/
	
	for(i=0;i<sl->n;i++)
	{
		sl->basin[i]=sl->sigma[i];
	}
	
	#pragma omp parallel for\
	shared(sl,coast,check,status,stalker,heap)\
	private(i,j,k,r,s,t,u,v,ithread)
	for(i=0;i<coast->m;i++)
	{
		ithread=omp_get_thread_num();
		
		/*SETTING_UP*/
		stalker[ithread].n=sl->n;
		stalker[ithread].m=0;
		heap[ithread].n=sl->n;
		heap[ithread].m=0;
		for(j=0;j<sl->n;j++)
		{
			check[ithread][j]=-2;
			status[ithread][j]=-2;
			
			stalker[ithread].val[j]=-2;
			stalker[ithread].lav[j]=-2;
			
			heap[ithread].ind[j]=-2;
			heap[ithread].val[j]=-2.;
		}
		/*SETTING_UP*/
		
		k=coast->val[i];
		invasion_percolation(&heap[ithread],sl,nei,status[ithread],k);
		
		for(j=0;j<sl->n;j++)
		{
			check[ithread][j]=sl->basin[j];
		}
		
		add_to_list(&stalker[ithread],k);
		check[ithread][k]=1;
		
		while(stalker[ithread].m>0)
		{
			t=stalker[ithread].val[0];
			remove_from_list(&stalker[ithread],t);
			
			for(r=nei->IM[t];r<nei->IM[t+1];r++) // from IA[i] to IA[i+1]-1
			{
				s=nei->JM[r];
				
				if(sl->basin[s]==-1)
				{
					invasion_percolation(&heap[ithread],sl,nei,status[ithread],s);
					if(sl->sigma[s]==sl->sigma[k])
					{
						for(u=nei->IV[s];u<nei->IV[s+1];u++) // from IA[i] to IA[i+1]-1
						{
							v=nei->JV[u];
							
							if(sl->basin[v]==-1)
							{
								invasion_percolation(&heap[ithread],sl,nei,status[ithread],v);
								if(sl->sigma[v]!=sl->sigma[k])
								{
									if(check[ithread][s]==-1)
									{
										add_to_list(&stalker[ithread],s);
										check[ithread][s]=1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	/*SETTING_UP*/
	for(i=0;i<nthreads;i++)
	{
		free(heap[i].val);
		free(heap[i].ind);
		
		free(stalker[i].lav);
		free(stalker[i].val);
		
		free(check[i]);
		free(status[i]);
	}
	free(heap);
	free(stalker);
	free(check);
	free(status);
	/*SETTING_UP*/
}

void invasion_percolation(struct binary_heap *heap,struct site_lattice *sl,struct site_neighborhood *nei,int *status,int k)
{
	bool stop;
	
	int r,s,t;
	int w;
	
	if(sl->sigma[k]==-1)
	{
		for(r=0;r<sl->n;r++)
		{
			status[r]=sl->basin[r];
		}
		
		heap->m=0;
		for(r=0;r<heap->n;r++)
		{
			heap->ind[r]=-2;
			heap->val[r]=-2.;
		}
		
		status[k]=1;
		min_heap_insert(heap,sl->h[k],k);
		
		stop=false;
		while(heap->m>0 && stop==false)
		{
			t=heap_extract_min(heap);
			
			status[t]=2;
			
			for(r=nei->IV[t];r<nei->IV[t+1];r++) // from IA[i] to IA[i+1]-1
			{
				s=nei->JV[r];
				
				if(status[s]==-2)
				{
					w=t;
					stop=true;
				}
			}
			
			if(stop==false)
			{
				for(r=nei->IV[t];r<nei->IV[t+1];r++) // from IA[i] to IA[i+1]-1
				{
					s=nei->JV[r];
					
					if(status[s]==-1)
					{
						status[s]=1;
						min_heap_insert(heap,sl->h[s],s);
					}
				}
			}
		}
		
		if(stop==true)
		{
			sl->sigma[k]=w;
		}
	}
}

void burning(struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land)
{
	int nburn,iburn;
	int *burn;
	
	int i,j,k;
	int r,s,t;
	int u,v,w;
	
/*	printf("BURNING\n");*/
	
	burn=(int *)malloc(sl->n*sizeof(int));
	for(i=0;i<land->m;i++)
	{
		k=land->val[i];
		
		if(sl->sigma[k]>-1)
		{
			for(r=0;r<sl->n;r++)
			{
				burn[r]=-2;
			}
			
			nburn=0;
			burn[nburn]=k;
			
			iburn=-1;
			while(iburn<nburn)
			{
				iburn=iburn+1;
				
				u=burn[iburn];
				
				for(j=nei->IV[u];j<nei->IV[u+1];j++) // from IA[i] to IA[i+1]-1
				{
					v=nei->JV[j];
					
					if(sl->sigma[v]==-1)
					{
						sl->sigma[v]=sl->sigma[k];
						
						nburn=nburn+1;
						burn[nburn]=v;
					}
				}
			}
		}
	}
	free(burn);
}

void output(struct site_lattice *sl,struct normal_list *land,char name1[100],char name2[100])
{
	FILE *f;
	char filename[400];
	
	int i,j,k;
	int u,v;
	
/*	printf("OUTPUT\n");*/
	
	strcpy(filename,"results/");
	strcat(filename,name1);
	strcat(filename,"/sigma_");
	strcat(filename,name2);
	strcat(filename,".dat");
	f=fopen(filename,"w");
	fprintf(f,"# %d %d %d %lf %lf %lf %lf\n",sl->lx,sl->ly,land->m,sl->lon0,sl->lat0,sl->delta,sl->R);
	for(i=0;i<land->m;i++)
	{
		k=land->val[i];
		
		u=k%sl->lx;
		v=k/sl->lx;
		
		fprintf(f,"%d %d %d\n",u,v,sl->sigma[k]);
	}
	fclose(f);
}

void add_to_list(struct normal_list *list,int k)
{
	if(list->m>list->n)
	{
		printf("m is greater than n!\n");
		exit(0);
	}
	
	if(list->lav[k]<0)
	{
		list->val[list->m]=k;
		list->lav[k]=list->m;
		list->m++;
	}
}

void remove_from_list(struct normal_list *list,int k)
{
	int i,j;
	
	if(list->m==0)
	{
		printf("m is zero!\n");
		exit(0);
	}
	
	if(list->lav[k]>=0)
	{
		if(list->lav[k]==list->m-1)
		{
			i=list->lav[k];
			list->lav[k]=-2;
			list->val[i]=-2;
			list->m--;
		}
		else
		{
			i=list->lav[k];
			list->lav[k]=-2;
			j=list->val[list->m-1];
			list->val[list->m-1]=-2;
			list->val[i]=j;
			list->lav[j]=i;
			list->m--;
		}
	}
}

int parent(int i)
{
	return i/2;
}

int left(int i)
{
	return 2*i;
}

int right(int i)
{
	return 2*i+1;
}

void min_heap_insert(struct binary_heap *Heap,float val_key,int key)
{
	Heap->m++;
	Heap->val[Heap->m-1]=FLT_MAX;
	
	heap_decrease_key(Heap,val_key,key);
}

void heap_decrease_key(struct binary_heap *Heap,float val_key,int key)
{
	int i;
	int p;
	int aux_ind;
	float aux_val;
	
	if(val_key>Heap->val[Heap->m-1])
	{
		printf("New key is larger than current key\n");
		exit(0);
	}
	
	Heap->ind[Heap->m-1]=key;
	Heap->val[Heap->m-1]=val_key;
	
	i=Heap->m;
	p=parent(i);
	while(i>1 && Heap->val[p-1]>Heap->val[i-1])
	{
		aux_ind=Heap->ind[i-1];
		Heap->ind[i-1]=Heap->ind[p-1];
		Heap->ind[p-1]=aux_ind;
		
		aux_val=Heap->val[i-1];
		Heap->val[i-1]=Heap->val[p-1];
		Heap->val[p-1]=aux_val;
		
		i=p;
		p=parent(i);
	}
}

int heap_extract_min(struct binary_heap *Heap)
{
	int imin;
	
	if(Heap->m<1)
	{
		printf("Heap underflow\n");
		exit(0);
	}
	
	imin=Heap->ind[0];
	
	Heap->ind[0]=Heap->ind[Heap->m-1];
	Heap->val[0]=Heap->val[Heap->m-1];
	Heap->m--;
	
	min_heapify(Heap,1);
	
	return imin;
}

void min_heapify(struct binary_heap *Heap,int i)
{
	int l;
	int r;
	int smallest;
	int aux_ind;
	float aux_val;
	
	l=left(i);
	r=right(i);
	
	if(l<=Heap->m && Heap->val[l-1]<Heap->val[i-1])
	{
		smallest=l;
	}
	else
	{
		smallest=i;
	}
	
	if(r<=Heap->m && Heap->val[r-1]<Heap->val[smallest-1])
	{
		smallest=r;
	}
	
	if(smallest!=i)
	{
		aux_ind=Heap->ind[i-1];
		Heap->ind[i-1]=Heap->ind[smallest-1];
		Heap->ind[smallest-1]=aux_ind;
		
		aux_val=Heap->val[i-1];
		Heap->val[i-1]=Heap->val[smallest-1];
		Heap->val[smallest-1]=aux_val;
		
		min_heapify(Heap,smallest);
	}
}

void max_heap_insert(struct binary_heap *heap,float val_key,int key)
{
	heap->m++;
	heap->val[heap->m-1]=-FLT_MAX;
	
	heap_increase_key(heap,val_key,key);
}

void heap_increase_key(struct binary_heap *heap,float val_key,int key)
{
	int i;
	int p;
	int aux_ind;
	float aux_val;
	
	if(val_key<heap->val[heap->m-1])
	{
		printf("New key is smaller than current key\n");
		exit(0);
	}
	
	heap->ind[heap->m-1]=key;
	heap->val[heap->m-1]=val_key;
	
	i=heap->m;
	p=parent(i);
	while(i>1 && heap->val[p-1]<heap->val[i-1])
	{
		aux_ind=heap->ind[i-1];
		heap->ind[i-1]=heap->ind[p-1];
		heap->ind[p-1]=aux_ind;
		
		aux_val=heap->val[i-1];
		heap->val[i-1]=heap->val[p-1];
		heap->val[p-1]=aux_val;
		
		i=p;
		p=parent(i);
	}
}

int heap_extract_max(struct binary_heap *heap)
{
	int imax;
	
	if(heap->m<1)
	{
		printf("heap underflow\n");
		exit(0);
	}
	
	imax=heap->ind[0];
	
	heap->ind[0]=heap->ind[heap->m-1];
	heap->val[0]=heap->val[heap->m-1];
	heap->m--;
	
	max_heapify(heap,1);
	
	return imax;
}

void max_heapify(struct binary_heap *heap,int i)
{
	int l;
	int r;
	int largest;
	int aux_ind;
	float aux_val;
	
	l=left(i);
	r=right(i);
	
	if(l<=heap->m && heap->val[l-1]>heap->val[i-1])
	{
		largest=l;
	}
	else
	{
		largest=i;
	}
	
	if(r<=heap->m && heap->val[r-1]>heap->val[largest-1])
	{
		largest=r;
	}
	
	if(largest!=i)
	{
		aux_ind=heap->ind[i-1];
		heap->ind[i-1]=heap->ind[largest-1];
		heap->ind[largest-1]=aux_ind;
		
		aux_val=heap->val[i-1];
		heap->val[i-1]=heap->val[largest-1];
		heap->val[largest-1]=aux_val;
		
		max_heapify(heap,largest);
	}
}
