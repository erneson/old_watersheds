#!/bin/bash

#gcc -fopenmp -lm -O3 -o inv_river inv_river.c

nthreads=4
hcutoff=0.0
acutoff=100000.0
filename1='GEBCO'
filename2='GEBCO_2014_2D_90N_90S_f8'
(time ./inv_river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> d.dat

#nthreads=4
#hcutoff=0.0
#acutoff=100000.0
#filename1='GEBCO'
#filename2='GEBCO_2014_2D_90N_90S_f4'
#(time ./inv_river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> d.dat

#nthreads=4
#hcutoff=0.0
#acutoff=100000.0
#filename1='GEBCO'
#filename2='GEBCO_2014_2D_90N_90S_f2'
#(time ./inv_river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> d.dat

#nthreads=4
#hcutoff=0.0
#acutoff=100000.0
#filename1='GEBCO'
#filename2='GEBCO_2014_2D_90N_90S_f1'
#(time ./inv_river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> d.dat
