#!/bin/bash

nthreads=$1
hcutoff=$2
acutoff=$3
filename1=$4
filename2=$5

mkdir -p results/inv_"$filename1"

./inv_river "$nthreads" "$hcutoff" "$acutoff" "$filename1" "$filename2"
