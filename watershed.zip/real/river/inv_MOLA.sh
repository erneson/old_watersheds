#!/bin/bash

#gcc -fopenmp -lm -O3 -o inv_river inv_river.c

nthreads=4
hcutoff=0.0
acutoff=10000.0
filename1='MOLA'
filename2='Mars_MGS_MOLA_DEM_mosaic_global_463m_90N_90S_f8'
(time ./inv_river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> f.dat

#nthreads=4
#hcutoff=0.0
#acutoff=10000.0
#filename1='MOLA'
#filename2='Mars_MGS_MOLA_DEM_mosaic_global_463m_90N_90S_f4'
#(time ./inv_river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> f.dat

#nthreads=4
#hcutoff=0.0
#acutoff=10000.0
#filename1='MOLA'
#filename2='Mars_MGS_MOLA_DEM_mosaic_global_463m_90N_90S_f2'
#(time ./inv_river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> f.dat

#nthreads=4
#hcutoff=0.0
#acutoff=100000.0
#filename1='MOLA'
#filename2='Mars_MGS_MOLA_DEM_mosaic_global_463m_90N_90S_f1'
#(time ./inv_river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> f.dat
