#!/bin/bash

#gcc -fopenmp -lm -O3 -o river river.c

nthreads=4
hcutoff=0.0
acutoff=1000.0
filename1='LOLA'
filename2='Lunar_LRO_LOLA_Global_LDEM_118m_Mar2014_90N_90S_f16'
(time ./river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> b.dat

#nthreads=4
#hcutoff=0.0
#acutoff=1000.0
#filename1='LOLA'
#filename2='Lunar_LRO_LOLA_Global_LDEM_118m_Mar2014_90N_90S_f8'
#(time ./river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> b.dat

#nthreads=4
#hcutoff=0.0
#acutoff=1000.0
#filename1='LOLA'
#filename2='Lunar_LRO_LOLA_Global_LDEM_118m_Mar2014_90N_90S_f4'
#(time ./river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> b.dat

#nthreads=4
#hcutoff=0.0
#acutoff=1000.0
#filename1='LOLA'
#filename2='Lunar_LRO_LOLA_Global_LDEM_118m_Mar2014_90N_90S_f2'
#(time ./river.sh $nthreads $hcutoff $acutoff $filename1 $filename2) 2>> b.dat
