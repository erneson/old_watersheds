#include <stdio.h>
#include <limits.h>
#include <float.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <omp.h>

#include <sys/stat.h>
#include <sys/types.h>

struct site_lattice
{
	int lx;
	int ly;
	int n;
	int m;
	double lon0;
	double lat0;
	double delta;
	double R;
	
	float *h;
	int *sigma;
	int *basin;
};

struct site_neighborhood
{
	int NNZV; // Compressed Row "Binary" Storage (CRBS)
	int *IV; // Compressed Row "Binary" Storage (CRBS)
	int *JV; // Compressed Row "Binary" Storage (CRBS)
	
	int NNZM; // Compressed Row "Binary" Storage (CRBS)
	int *IM;// Compressed Row "Binary" Storage (CRBS)
	int *JM; // Compressed Row "Binary" Storage (CRBS)
};

struct normal_list
{
	int n;
	int m;
	int *val;
	int *lav;
};

struct binary_heap
{
	int n;
	int m;
	int *ind;
	float *val;
};

void input(float hcutoff,char name1[100],char name2[100],struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land);

void coastline(struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land,struct normal_list *coast);
void drainage_basin(int nthreads,struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *coast);
void invasion_percolation(struct binary_heap *heap,struct site_lattice *sl,struct site_neighborhood *nei,int *status,int k);
void burning(struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land);

void reinput(int i,struct site_lattice *sl0,struct normal_list *land0,struct site_lattice *sl1,struct normal_list *land1);
void reoutput(int i,struct site_lattice *sl1,struct normal_list *land1,char name1[100],char name2[100]);

void add_to_list(struct normal_list *list,int k);
void remove_from_list(struct normal_list *list,int k);

int parent(int i);
int left(int i);
int right(int i);

void min_heap_insert(struct binary_heap *Heap,float val_key,int key);
void heap_decrease_key(struct binary_heap *Heap,float val_key,int key);
int heap_extract_min(struct binary_heap *Heap);
void min_heapify(struct binary_heap *Heap,int i);
void build_min_heap(struct binary_heap *heap);
void heapsort_min(struct binary_heap *heap);

void max_heap_insert(struct binary_heap *heap,float val_key,int key);
void heap_increase_key(struct binary_heap *heap,float val_key,int key);
int heap_extract_max(struct binary_heap *heap);
void max_heapify(struct binary_heap *heap,int i);
void build_max_heap(struct binary_heap *heap);
void heapsort_max(struct binary_heap *heap);

double geodist(double lon1, double lat1, double lon2, double lat2, double r);
double sphetriare(double delta, double lon0, double lat0, double r);

int main(int argc,char *argv[])
{
	int nthreads;
	float hcutoff;
	float acutoff;
	char name1[100];
	char name2[100];
	
	struct site_neighborhood *nei;
	
	struct site_lattice *sl0;
	struct normal_list *land0;
	struct normal_list *coast0;
	
	double *A;
	struct binary_heap *area0;
	double lon,lat;
	
	struct site_lattice *sl1;
	struct normal_list *land1;
	struct normal_list *coast1;
	
	int i,j,k;
	int r,s;
	int u,v,w;
	
	/*/////////*/
	/*WATERSHED*/
	/*/////////*/
	nthreads=atoi(argv[1]);
	hcutoff=atof(argv[2]);
	acutoff=atof(argv[3]);
	strcpy(name1,argv[4]);
	strcpy(name2,argv[5]);
	
	/*INPUT*/
	nei=(struct site_neighborhood *)malloc(sizeof(struct site_neighborhood));
	sl0=(struct site_lattice *)malloc(sizeof(struct site_lattice));
	land0=(struct normal_list *)malloc(sizeof(struct normal_list));
	input(hcutoff,name1,name2,sl0,nei,land0);
	/*INPUT*/
	
	/*COASTLINE*/
	coast0=(struct normal_list *)malloc(sizeof(struct normal_list));
	coastline(sl0,nei,land0,coast0);
	/*COASTLINE*/
	
	/*//////////*/
	/*///AREA///*/
	/*//////////*/
	
	/*SETTING_UP*/
	A=(double *)malloc(sl0->n*sizeof(double));
	for(i=0;i<sl0->n;i++)
	{
		A[i]=0.;
	}
	
	area0=(struct binary_heap *)malloc(sizeof(struct binary_heap));
	area0->n=sl0->n;
	area0->m=0;
	area0->ind=(int *)malloc(area0->n*sizeof(int));
	area0->val=(float *)malloc(area0->n*sizeof(float));
	for(i=0;i<area0->n;i++)
	{
		area0->ind[i]=-2;
		area0->val[i]=-2.;
	}
	/*SETTING_UP*/
	
	for(i=0;i<land0->m;i++)
	{
		k=land0->val[i];
		
		u=sl0->sigma[k];
		v=coast0->lav[u];
		
		r=k%sl0->lx;
		s=k/sl0->lx;
		lon=sl0->lon0+(r-0.5)*sl0->delta;
		lat=sl0->lat0-(s+0.5)*sl0->delta;
		
		A[v]=A[v]+sphetriare(sl0->delta,lon,lat,sl0->R);
	}
	
	for(i=0;i<sl0->n;i++)
	{
		area0->ind[i]=i;
		area0->val[i]=(float)A[i];
	}
	
	heapsort_min(area0);
	/*//////////*/
	/*///AREA///*/
	/*//////////*/
	
	for(i=0;i<coast0->m;i++)
	{
		if(area0->val[i]>acutoff)
		{
			k=coast0->val[area0->ind[i]];
			
			/*/////*/
			/*RIVER*/
			/*/////*/
			
			/*REINPUT*/
			sl1=(struct site_lattice *)malloc(sizeof(struct site_lattice));
			land1=(struct normal_list *)malloc(sizeof(struct normal_list));
			reinput(k,sl0,land0,sl1,land1);
			/*REINPUT*/
			
			/*COASTLINE*/
			coast1=(struct normal_list *)malloc(sizeof(struct normal_list));
			coastline(sl1,nei,land1,coast1);
			/*COASTLINE*/
			
			/*DRAINAGE_BASIN*/
			drainage_basin(nthreads,sl1,nei,coast1);
			/*DRAINAGE_BASIN*/
			
			/*BURNING*/
			burning(sl1,nei,land1);
			/*BURNING*/
			
			/*OUTPUT*/
			reoutput(k,sl1,land1,name1,name2);
			/*OUTPUT*/
			
			free(coast1->lav);
			free(coast1->val);
			free(coast1);
			
			free(land1->lav);
			free(land1->val);
			free(land1);
			
			free(sl1->basin);
			free(sl1->sigma);
			free(sl1->h);
			free(sl1);
			
			/*/////*/
			/*RIVER*/
			/*/////*/
		}
	}
	
	free(area0->ind);
	free(area0->val);
	free(area0);
	
	free(A);
	
	free(coast0->lav);
	free(coast0->val);
	free(coast0);
	
	free(land0->lav);
	free(land0->val);
	free(land0);
	
	free(sl0->basin);
	free(sl0->sigma);
	free(sl0->h);
	free(sl0);
	
	free(nei->JM);
	free(nei->IM);
	free(nei->JV);
	free(nei->IV);
	
	/*/////////*/
	/*WATERSHED*/
	/*/////////*/
	
	return(0);
}

void input(float hcutoff,char name1[100],char name2[100],struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land)
{
	char filename[400];
	FILE *f;
	char hashtag;
	int lx,ly;
	int m;
	double lon0,lat0;
	double delta;
	double R;
	
	float height;
	
	/*SIGMA*/
	int status;
	/*SIGMA*/
	
	int i,j,k;
	int r,s,t;
	int w;
	
/*	printf("INPUT\n");*/
	
	strcpy(filename,"../datasets/");
	strcat(filename,name1);
	strcat(filename,"/");
	strcat(filename,name2);
	strcat(filename,".dat");
	f=fopen(filename,"r");
	fscanf(f,"%c %d %d %d %lf %lf %lf %lf\n",&hashtag,&lx,&ly,&m,&lon0,&lat0,&delta,&R);
	
	/*SETTING_UP*/
	sl->lx=lx;
	sl->ly=ly;
	sl->n=sl->lx*sl->ly;
	sl->m=m;
	sl->lon0=lon0;
	sl->lat0=lat0;
	sl->delta=delta;
	sl->R=R;
	sl->h=(float *)malloc(sl->n*sizeof(float));
	sl->sigma=(int *)malloc(sl->n*sizeof(int));
	sl->basin=(int *)malloc(sl->n*sizeof(int));
	land->n=sl->n;
	land->m=0;
	land->val=(int *)malloc(sl->n*sizeof(int));
	land->lav=(int *)malloc(sl->n*sizeof(int));
	/*PBC*/
	nei->NNZV=2*sl->lx*(sl->lx+2*sl->ly-4);
	nei->IV=(int *)malloc((sl->n+1)*sizeof(int));
	nei->JV=(int *)malloc(nei->NNZV*sizeof(int));
	nei->NNZM=2*sl->lx*(sl->lx+4*sl->ly-6);
	nei->IM=(int *)malloc((sl->n+1)*sizeof(int));
	nei->JM=(int *)malloc(nei->NNZM*sizeof(int));
	/*PBC*/
	
	for(i=0;i<sl->n;i++)
	{
		sl->h[i]=-2.;
		sl->sigma[i]=-2;
		sl->basin[i]=-2;
		
		land->val[i]=-2;
		land->lav[i]=-2;
	}
	/*PBC*/
	for(i=0;i<sl->n+1;i++)
	{
		nei->IV[i]=-2;
		nei->IM[i]=-2;
	}
	for(i=0;i<nei->NNZV;i++)
	{
		nei->JV[i]=-2;
	}
	for(i=0;i<nei->NNZM;i++)
	{
		nei->JM[i]=-2;
	}
	/*PBC*/
	/*SETTING_UP*/
	
	/*PBC*/
	t=0;
	w=0;
	nei->IV[0]=t;
	nei->IM[0]=w;
	for(k=0;k<sl->n;k++)
	{
		i=k%sl->lx;
		j=k/sl->lx;
		
		if(j==0)
		{
			if(i==0)
			{
				/*VON NEUMMAN*/
				nei->JV[t]=k+1;
				t=t+1;
				for(r=0;r<sl->lx;r++)
				{
					s=r;
					
					if(s!=k+sl->lx-1 && s!=k && s!=k+1)
					{
						nei->JV[t]=s; // PBC
						t=t+1;
					}
				}
				nei->JV[t]=k+sl->lx-1; // PBC
				t=t+1;
				nei->JV[t]=k+sl->lx;
				t=t+1;
				
				nei->IV[k+1]=t;
				/*VON NEUMMAN*/
				
				/*MOORE*/
				nei->JM[w]=k+1;
				w=w+1;
				for(r=0;r<sl->lx;r++)
				{
					s=r;
					
					if(s!=k+sl->lx-1 && s!=k && s!=k+1)
					{
						nei->JM[w]=s; // PBC
						w=w+1;
					}
				}
				nei->JM[w]=k+sl->lx-1; // PBC
				w=w+1;
				nei->JM[w]=k+sl->lx;
				w=w+1;
				nei->JM[w]=k+1+sl->lx;
				w=w+1;
				nei->JM[w]=k+2*sl->lx-1; // PBC
				w=w+1;
				
				nei->IM[k+1]=w;
				/*MOORE*/
			}
			else
			{
				if(i==sl->lx-1)
				{
					/*VON NEUMMAN*/
					nei->JV[t]=k-sl->lx+1; // PBC
					t=t+1;
					for(r=0;r<sl->lx;r++)
					{
						s=r;
						
						if(s!=k-1 && s!=k && s!=k-sl->lx+1)
						{
							nei->JV[t]=s; // PBC
							t=t+1;
						}
					}
					nei->JV[t]=k-1;
					t=t+1;
					nei->JV[t]=k+sl->lx;
					t=t+1;
					
					nei->IV[k+1]=t;
					/*VON NEUMMAN*/
					
					/*MOORE*/
					nei->JM[w]=k-sl->lx+1; // PBC
					w=w+1;
					for(r=0;r<sl->lx;r++)
					{
						s=r;
						
						if(s!=k-1 && s!=k && s!=k-sl->lx+1)
						{
							nei->JM[w]=s; // PBC
							w=w+1;
						}
					}
					nei->JM[w]=k-1;
					w=w+1;
					nei->JM[w]=k+1; // PBC
					w=w+1;
					nei->JM[w]=k-1+sl->lx;
					w=w+1;
					nei->JM[w]=k+sl->lx;
					w=w+1;
					
					nei->IM[k+1]=w;
					/*MOORE*/
				}
				else
				{
					/*VON NEUMMAN*/
					for(r=0;r<sl->lx;r++)
					{
						s=r;
						
						if(s!=k-1 && s!=k && s!=k+1)
						{
							nei->JV[t]=s; // PBC
							t=t+1;
						}
						else
						{
							if(s==k-1)
							{
								nei->JV[t]=s;
								t=t+1;
							}
							
							if(s==k+1)
							{
								nei->JV[t]=s;
								t=t+1;
							}
						}
					}
					nei->JV[t]=k+sl->lx;
					t=t+1;
					
					nei->IV[k+1]=t;
					/*VON NEUMMAN*/
					
					/*MOORE*/
					for(r=0;r<sl->lx;r++)
					{
						s=r;
						
						if(s!=k-1 && s!=k && s!=k+1)
						{
							nei->JM[w]=s; // PBC
							w=w+1;
						}
						else
						{
							if(s==k-1)
							{
								nei->JM[t]=s;
								w=w+1;
							}
							
							if(s==k+1)
							{
								nei->JM[t]=s;
								w=w+1;
							}
						}
					}
					nei->JM[w]=k-1+sl->lx;
					w=w+1;
					nei->JM[w]=k+sl->lx;
					w=w+1;
					nei->JM[w]=k+1+sl->lx;
					w=w+1;
					
					nei->IM[k+1]=w;
					/*MOORE*/
				}
			}
		}
		else
		{
			if(j<sl->ly-1) //k<=(sl->ly-1)*sl->lx-1
			{
				if(i==0)
				{
					/*VON NEUMMAN*/
					nei->JV[t]=k-sl->lx;
					t=t+1;
					nei->JV[t]=k+1;
					t=t+1;
					nei->JV[t]=k-1+sl->lx; // PBC
					t=t+1;
					nei->JV[t]=k+sl->lx;
					t=t+1;
					
					nei->IV[k+1]=t;
					/*VON NEUMMAN*/
					
					/*MOORE*/
					nei->JM[w]=k-sl->lx;
					w=w+1;
					nei->JM[w]=k+1-sl->lx; //PBC
					w=w+1;
					nei->JM[w]=k-1;
					w=w+1;
					nei->JM[w]=k+1;
					w=w+1;
					nei->JM[w]=k-1+sl->lx; // PBC
					w=w+1;
					nei->JM[w]=k+sl->lx;
					w=w+1;
					nei->JM[w]=k+1+sl->lx;
					w=w+1;
					nei->JM[w]=k-1+2*sl->lx; // PBC
					w=w+1;
					
					nei->IM[k+1]=w;
					/*MOORE*/
				}
				else
				{
					if(i==sl->lx-1)
					{
						/*VON NEUMMAN*/
						nei->JV[t]=k-sl->lx;
						t=t+1;
						nei->JV[t]=k-sl->lx+1; // PBC
						t=t+1;
						nei->JV[t]=k-1;
						t=t+1;
						nei->JV[t]=k+sl->lx;
						t=t+1;
						
						nei->IV[k+1]=t;
						/*VON NEUMMAN*/
						
						/*MOORE*/
						nei->JM[w]=k-2*sl->lx+1; // PBC
						w=w+1;
						nei->JM[w]=k-1-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx+1; // PBC
						w=w+1;
						nei->JM[w]=k-1;
						w=w+1;
						nei->JM[w]=k+1; // PBC
						w=w+1;
						nei->JM[w]=k-1+sl->lx;
						w=w+1;
						nei->JM[w]=k+sl->lx;
						w=w+1;
						
						nei->IM[k+1]=w;
						/*MOORE*/
					}
					else
					{
						/*VON NEUMMAN*/
						nei->JV[t]=k-sl->lx;
						t=t+1;
						nei->JV[t]=k-1;
						t=t+1;
						nei->JV[t]=k+1;
						t=t+1;
						nei->JV[t]=k+sl->lx;
						t=t+1;
						
						nei->IV[k+1]=t;
						/*VON NEUMMAN*/
						
						/*MOORE*/
						nei->JM[w]=k-1-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx;
						w=w+1;
						nei->JM[w]=k+1-sl->lx;
						w=w+1;
						nei->JM[w]=k-1;
						w=w+1;
						nei->JM[w]=k+1;
						w=w+1;
						nei->JM[w]=k-1+sl->lx;
						w=w+1;
						nei->JM[w]=k+sl->lx;
						w=w+1;
						nei->JM[w]=k+1+sl->lx;
						w=w+1;
						
						nei->IM[k+1]=w;
						/*MOORE*/
					}
				}
			}
			else
			{
				if(i==0)
				{
					/*VON NEUMMAN*/
					nei->JV[t]=k-sl->lx;
					t=t+1;
					nei->JV[t]=k+1;
					t=t+1;
					for(r=0;r<sl->lx;r++)
					{
						s=r+(sl->ly-1)*sl->lx;
						
						if(s!=k-1+sl->lx && s!=k && s!=k+1)
						{
							nei->JV[t]=s; // PBC
							t=t+1;
						}
					}
					nei->JV[t]=k-1+sl->lx; // PBC
					t=t+1;
					
					nei->IV[k+1]=t;
					/*VON NEUMMAN*/
					
					/*MOORE*/
					nei->JM[w]=k-sl->lx;
					w=w+1;
					nei->JM[w]=k+1-sl->lx;
					w=w+1;
					nei->JM[w]=k-1; // PBC
					w=w+1;
					nei->JM[w]=k+1;
					w=w+1;
					for(r=0;r<sl->lx;r++)
					{
						s=r+(sl->ly-1)*sl->lx;
						
						if(s!=k-1+sl->lx && s!=k && s!=k+1)
						{
							nei->JM[w]=s; // PBC
							w=w+1;
						}
					}
					nei->JM[w]=k-1+sl->lx; // PBC
					w=w+1;
					
					nei->IM[k+1]=w;
					/*MOORE*/
				}
				else
				{
					if(i==sl->lx-1)
					{
						/*VON NEUMMAN*/
						nei->JV[t]=k-sl->lx;
						t=t+1;
						nei->JV[t]=k-sl->lx+1; // PBC
						t=t+1;						
						for(r=0;r<sl->lx;r++)
						{
							s=r+(sl->ly-1)*sl->lx;
							
							if(s!=k-1 && s!=k && s!=k-sl->lx+1)
							{
								nei->JV[t]=s; // PBC
								t=t+1;
							}
						}
						nei->JV[t]=k-1;
						t=t+1;
						
						nei->IV[k+1]=t;
						/*VON NEUMMAN*/
						
						/*MOORE*/
						nei->JM[w]=k-2*sl->lx+1; // PBC
						w=w+1;
						nei->JM[w]=k-1-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx+1; // PBC
						w=w+1;
						for(r=0;r<sl->lx;r++)
						{
							s=r+(sl->ly-1)*sl->lx;
							
							if(s!=k-1 && s!=k && s!=k-sl->lx+1)
							{
								nei->JM[w]=s; // PBC
								w=w+1;
							}
						}
						nei->JM[w]=k-1;
						w=w+1;
						
						nei->IM[k+1]=w;
						/*MOORE*/
					}
					else
					{
						/*VON NEUMMAN*/
						nei->JV[t]=k-sl->lx;
						t=t+1;
						for(r=0;r<sl->lx;r++)
						{
							s=r+(sl->ly-1)*sl->lx;
							
							if(s!=k-1 && s!=k && s!=k+1)
							{
								nei->JV[t]=s; // PBC
								t=t+1;
							}
							else
							{
								if(s==k-1)
								{
									nei->JV[t]=s;
									t=t+1;
								}
								
								if(s==k+1)
								{
									nei->JV[t]=s;
									t=t+1;
								}
							}
						}
						
						nei->IV[k+1]=t;
						/*VON NEUMMAN*/
						
						/*MOORE*/
						nei->JM[w]=k-1-sl->lx;
						w=w+1;
						nei->JM[w]=k-sl->lx;
						w=w+1;
						nei->JM[w]=k+1-sl->lx;
						w=w+1;
						for(r=0;r<sl->lx;r++)
						{
							s=r+(sl->ly-1)*sl->lx;
							
							if(s!=k-1 && s!=k && s!=k+1)
							{
								nei->JM[w]=s; // PBC
								w=w+1;
							}
							else
							{
								if(s==k-1)
								{
									nei->JM[w]=s;
									w=w+1;
								}
								
								if(s==k+1)
								{
									nei->JM[w]=s;
									w=w+1;
								}
							}
						}
						
						nei->IM[k+1]=w;
						/*MOORE*/
					}
				}
			}
		}
	}
	/*PBC*/
	
	srand(123); // Seed of the random function
	for(r=0;r<sl->m;r++)
	{
		fscanf(f,"%d %d %f\n",&i,&j,&height);
		k=i+j*sl->lx;
		
		height=height+0.1*(float)rand()/(float)RAND_MAX; //To avoid sites of exactly the same height
		
		sl->h[k]=-height; // UPSIDE DOWN LANDSCAPE
		
		if(sl->h[k]>hcutoff)
		{
			add_to_list(land,k);
			
			sl->sigma[k]=-1;
		}
	}
	fclose(f);
	
	/*SIGMA*/
	strcpy(filename,"../watershed/results/inv_");
	strcat(filename,name1);
	strcat(filename,"/sigma_");
	strcat(filename,name2);
	strcat(filename,".dat");
	f=fopen(filename,"r");
	fscanf(f,"%c %d %d %d %lf %lf %lf %lf\n",&hashtag,&lx,&ly,&m,&lon0,&lat0,&delta,&R);
	for(r=0;r<sl->m;r++)
	{
		fscanf(f,"%d %d %d\n",&i,&j,&status);
		k=i+j*sl->lx;
		
		sl->sigma[k]=status;
	}
	fclose(f);
	/*SIGMA*/
}

void reinput(int k,struct site_lattice *sl0,struct normal_list *land0,struct site_lattice *sl1,struct normal_list *land1)
{
	float max_height;
	
	int r,s,t;
	int u,v,w;
	
/*	printf("REINPUT\n");*/
	
	/*SETTING_UP*/
	sl1->lx=sl0->lx;
	sl1->ly=sl0->ly;
	sl1->n=sl1->lx*sl1->ly;
	sl1->m=sl0->m;
	sl1->lon0=sl0->lon0;
	sl1->lat0=sl0->lat0;
	sl1->delta=sl0->delta;
	sl1->R=sl0->R;
	sl1->h=(float *)malloc(sl1->n*sizeof(float));
	sl1->sigma=(int *)malloc(sl1->n*sizeof(int));
	sl1->basin=(int *)malloc(sl1->n*sizeof(int));
	land1->n=sl1->n;
	land1->m=0;
	land1->val=(int *)malloc(sl1->n*sizeof(int));
	land1->lav=(int *)malloc(sl1->n*sizeof(int));
	for(r=0;r<sl1->n;r++)
	{
		sl1->h[r]=-2.;
		sl1->sigma[r]=-2;
		sl1->basin[r]=-2;
		
		land1->val[r]=-2;
		land1->lav[r]=-2;
	}
	/*SETTING_UP*/
	
	max_height=-FLT_MAX;
	for(r=0;r<land0->m;r++)
	{
		t=land0->val[r];
		
		if(sl0->sigma[t]==k)
		{
			add_to_list(land1,t);
			
			sl1->h[t]=sl0->h[t];
			sl1->sigma[t]=-1;
			
			if(sl1->h[t]>max_height)
			{
				max_height=sl1->h[t];
			}
		}
	}
	
	for(r=0;r<land1->m;r++)
	{
		t=land1->val[r];
		
		sl1->h[t]=-sl1->h[t]+max_height;
	}
}

void coastline(struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land,struct normal_list *coast)
{
	int i,k;
	int r,s;
	
/*	printf("COAST\n");*/
	
	/*SETTING_UP*/
	coast->n=sl->n;
	coast->m=0;
	coast->val=(int *)malloc(coast->n*sizeof(int));
	coast->lav=(int *)malloc(coast->n*sizeof(int));
	for(i=0;i<coast->n;i++)
	{
		coast->val[i]=-2;
		coast->lav[i]=-2;
	}
	/*SETTING_UP*/
	
	for(i=0;i<land->m;i++)
	{
		k=land->val[i];
		
		for(r=nei->IV[k];r<nei->IV[k+1];r++) // from IA[i] to IA[i+1]-1
		{
			s=nei->JV[r];
			
			if(sl->sigma[s]==-2)
			{
				add_to_list(coast,k);
			}
		}
	}
}

void drainage_basin(int nthreads,struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *coast)
{
	int **check;
	int **status;
	struct normal_list *stalker;
	struct binary_heap *heap;
	
	int i,j,k;
	int r,s,t;
	int u,v;
	
	int ithread;
	
/*	printf("DRAINAGE_BASIN\n");*/
	
	/*OPENMP*/
	omp_set_dynamic(0);
	omp_set_num_threads(nthreads);
	/*OPENMP*/
	
	/*SETTING_UP*/
	check=(int **)malloc(nthreads*sizeof(int *));
	status=(int **)malloc(nthreads*sizeof(int *));
	stalker=(struct normal_list *)malloc(nthreads*sizeof(struct normal_list));
	heap=(struct binary_heap *)malloc(nthreads*sizeof(struct binary_heap));
	for(i=0;i<nthreads;i++)
	{
		check[i]=(int *)malloc(sl->n*sizeof(int));
		status[i]=(int *)malloc(sl->n*sizeof(int));
		
		stalker[i].val=(int *)malloc(sl->n*sizeof(int));
		stalker[i].lav=(int *)malloc(sl->n*sizeof(int));
		
		heap[i].ind=(int *)malloc(sl->n*sizeof(int));
		heap[i].val=(float *)malloc(sl->n*sizeof(float));
	}
	/*SETTING_UP*/
	
	for(i=0;i<sl->n;i++)
	{
		sl->basin[i]=sl->sigma[i];
	}
	
	#pragma omp parallel for\
	shared(sl,coast,check,status,stalker,heap)\
	private(i,j,k,r,s,t,u,v,ithread)
	for(i=0;i<coast->m;i++)
	{
		ithread=omp_get_thread_num();
		
		/*SETTING_UP*/
		stalker[ithread].n=sl->n;
		stalker[ithread].m=0;
		heap[ithread].n=sl->n;
		heap[ithread].m=0;
		for(j=0;j<sl->n;j++)
		{
			check[ithread][j]=-2;
			status[ithread][j]=-2;
			
			stalker[ithread].val[j]=-2;
			stalker[ithread].lav[j]=-2;
			
			heap[ithread].ind[j]=-2;
			heap[ithread].val[j]=-2.;
		}
		/*SETTING_UP*/
		
		k=coast->val[i];
		invasion_percolation(&heap[ithread],sl,nei,status[ithread],k);
		
		for(j=0;j<sl->n;j++)
		{
			check[ithread][j]=sl->basin[j];
		}
		
		add_to_list(&stalker[ithread],k);
		check[ithread][k]=1;
		
		while(stalker[ithread].m>0)
		{
			t=stalker[ithread].val[0];
			remove_from_list(&stalker[ithread],t);
			
			for(r=nei->IM[t];r<nei->IM[t+1];r++) // from IA[i] to IA[i+1]-1
			{
				s=nei->JM[r];
				
				if(sl->basin[s]==-1)
				{
					invasion_percolation(&heap[ithread],sl,nei,status[ithread],s);
					if(sl->sigma[s]==sl->sigma[k])
					{
						for(u=nei->IV[s];u<nei->IV[s+1];u++) // from IA[i] to IA[i+1]-1
						{
							v=nei->JV[u];
							
							if(sl->basin[v]==-1)
							{
								invasion_percolation(&heap[ithread],sl,nei,status[ithread],v);
								if(sl->sigma[v]!=sl->sigma[k])
								{
									if(check[ithread][s]==-1)
									{
										add_to_list(&stalker[ithread],s);
										check[ithread][s]=1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	/*SETTING_UP*/
	for(i=0;i<nthreads;i++)
	{
		free(heap[i].val);
		free(heap[i].ind);
		
		free(stalker[i].lav);
		free(stalker[i].val);
		
		free(check[i]);
		free(status[i]);
	}
	free(heap);
	free(stalker);
	free(check);
	free(status);
	/*SETTING_UP*/
}

void invasion_percolation(struct binary_heap *heap,struct site_lattice *sl,struct site_neighborhood *nei,int *status,int k)
{
	bool stop;
	
	int r,s,t;
	int w;
	
	if(sl->sigma[k]==-1)
	{
		for(r=0;r<sl->n;r++)
		{
			status[r]=sl->basin[r];
		}
		
		heap->m=0;
		for(r=0;r<heap->n;r++)
		{
			heap->ind[r]=-2;
			heap->val[r]=-2.;
		}
		
		status[k]=1;
		min_heap_insert(heap,sl->h[k],k);
		
		stop=false;
		while(heap->m>0 && stop==false)
		{
			t=heap_extract_min(heap);
			
			status[t]=2;
			
			for(r=nei->IV[t];r<nei->IV[t+1];r++) // from IA[i] to IA[i+1]-1
			{
				s=nei->JV[r];
				
				if(status[s]==-2)
				{
					w=t;
					stop=true;
				}
			}
			
			if(stop==false)
			{
				for(r=nei->IV[t];r<nei->IV[t+1];r++) // from IA[i] to IA[i+1]-1
				{
					s=nei->JV[r];
					
					if(status[s]==-1)
					{
						status[s]=1;
						min_heap_insert(heap,sl->h[s],s);
					}
				}
			}
		}
		
		if(stop==true)
		{
			sl->sigma[k]=w;
		}
	}
}

void burning(struct site_lattice *sl,struct site_neighborhood *nei,struct normal_list *land)
{
	int nburn,iburn;
	int *burn;
	
	int i,j,k;
	int r,s,t;
	int u,v,w;
	
/*	printf("BURNING\n");*/
	
	burn=(int *)malloc(sl->n*sizeof(int));
	for(i=0;i<land->m;i++)
	{
		k=land->val[i];
		
		if(sl->sigma[k]>-1)
		{
			for(r=0;r<sl->n;r++)
			{
				burn[r]=-2;
			}
			
			nburn=0;
			burn[nburn]=k;
			
			iburn=-1;
			while(iburn<nburn)
			{
				iburn=iburn+1;
				
				u=burn[iburn];
				
				for(j=nei->IV[u];j<nei->IV[u+1];j++) // from IA[i] to IA[i+1]-1
				{
					v=nei->JV[j];
					
					if(sl->sigma[v]==-1)
					{
						sl->sigma[v]=sl->sigma[k];
						
						nburn=nburn+1;
						burn[nburn]=v;
					}
				}
			}
		}
	}
	free(burn);
}

void reoutput(int k,struct site_lattice *sl1,struct normal_list *land1,char name1[100],char name2[100])
{
	FILE *f;
	char filename[400];
	char num[100];
	
	int r,t;
	int u,v;
	
/*	printf("REOUTPUT\n");*/
	
	strcpy(filename,"results/inv_");
	strcat(filename,name1);
	strcat(filename,"/sigma_");
	strcat(filename,name2);
	strcat(filename,"_");
	sprintf(num,"%08d",k);
	strcat(filename,num);
	strcat(filename,".dat");
	
	f=fopen(filename,"w");
	fprintf(f,"# %d %d %d %lf %lf %lf %lf\n",sl1->lx,sl1->ly,land1->m,sl1->lon0,sl1->lat0,sl1->delta,sl1->R);
	for(r=0;r<land1->m;r++)
	{
		t=land1->val[r];
		
		u=t%sl1->lx;
		v=t/sl1->lx;
		
		fprintf(f,"%d %d %d\n",u,v,sl1->sigma[t]);
	}
	fclose(f);
}

void add_to_list(struct normal_list *list,int k)
{
	if(list->m>list->n)
	{
		printf("m is greater than n!\n");
		exit(0);
	}
	
	if(list->lav[k]<0)
	{
		list->val[list->m]=k;
		list->lav[k]=list->m;
		list->m++;
	}
}

void remove_from_list(struct normal_list *list,int k)
{
	int i,j;
	
	if(list->m==0)
	{
		printf("m is zero!\n");
		exit(0);
	}
	
	if(list->lav[k]>=0)
	{
		if(list->lav[k]==list->m-1)
		{
			i=list->lav[k];
			list->lav[k]=-2;
			list->val[i]=-2;
			list->m--;
		}
		else
		{
			i=list->lav[k];
			list->lav[k]=-2;
			j=list->val[list->m-1];
			list->val[list->m-1]=-2;
			list->val[i]=j;
			list->lav[j]=i;
			list->m--;
		}
	}
}

int parent(int i)
{
	return i/2;
}

int left(int i)
{
	return 2*i;
}

int right(int i)
{
	return 2*i+1;
}

void min_heap_insert(struct binary_heap *Heap,float val_key,int key)
{
	Heap->m++;
	Heap->val[Heap->m-1]=FLT_MAX;
	
	heap_decrease_key(Heap,val_key,key);
}

void heap_decrease_key(struct binary_heap *Heap,float val_key,int key)
{
	int i;
	int p;
	int aux_ind;
	float aux_val;
	
	if(val_key>Heap->val[Heap->m-1])
	{
		printf("New key is larger than current key\n");
		exit(0);
	}
	
	Heap->ind[Heap->m-1]=key;
	Heap->val[Heap->m-1]=val_key;
	
	i=Heap->m;
	p=parent(i);
	while(i>1 && Heap->val[p-1]>Heap->val[i-1])
	{
		aux_ind=Heap->ind[i-1];
		Heap->ind[i-1]=Heap->ind[p-1];
		Heap->ind[p-1]=aux_ind;
		
		aux_val=Heap->val[i-1];
		Heap->val[i-1]=Heap->val[p-1];
		Heap->val[p-1]=aux_val;
		
		i=p;
		p=parent(i);
	}
}

int heap_extract_min(struct binary_heap *Heap)
{
	int imin;
	
	if(Heap->m<1)
	{
		printf("Heap underflow\n");
		exit(0);
	}
	
	imin=Heap->ind[0];
	
	Heap->ind[0]=Heap->ind[Heap->m-1];
	Heap->val[0]=Heap->val[Heap->m-1];
	Heap->m--;
	
	min_heapify(Heap,1);
	
	return imin;
}

void min_heapify(struct binary_heap *Heap,int i)
{
	int l;
	int r;
	int smallest;
	int aux_ind;
	float aux_val;
	
	l=left(i);
	r=right(i);
	
	if(l<=Heap->m && Heap->val[l-1]<Heap->val[i-1])
	{
		smallest=l;
	}
	else
	{
		smallest=i;
	}
	
	if(r<=Heap->m && Heap->val[r-1]<Heap->val[smallest-1])
	{
		smallest=r;
	}
	
	if(smallest!=i)
	{
		aux_ind=Heap->ind[i-1];
		Heap->ind[i-1]=Heap->ind[smallest-1];
		Heap->ind[smallest-1]=aux_ind;
		
		aux_val=Heap->val[i-1];
		Heap->val[i-1]=Heap->val[smallest-1];
		Heap->val[smallest-1]=aux_val;
		
		min_heapify(Heap,smallest);
	}
}

void build_min_heap(struct binary_heap *heap)
{
	int i;
	
	heap->m=heap->n;
	
	for(i=heap->n/2;i>0;i--)
	{
		min_heapify(heap,i);
	}
}

void heapsort_min(struct binary_heap *heap)
{
	int aux_ind;
	float aux_val;
	
	int i;
	
	build_min_heap(heap);
	
	for(i=heap->n;i>1;i--)
	{
		aux_ind=heap->ind[i-1];
		heap->ind[i-1]=heap->ind[0];
		heap->ind[0]=aux_ind;
		
		aux_val=heap->val[i-1];
		heap->val[i-1]=heap->val[0];
		heap->val[0]=aux_val;
		
		heap->m--;
		
		min_heapify(heap,1);
	}
}

void max_heap_insert(struct binary_heap *heap,float val_key,int key)
{
	heap->m++;
	heap->val[heap->m-1]=-FLT_MAX;
	
	heap_increase_key(heap,val_key,key);
}

void heap_increase_key(struct binary_heap *heap,float val_key,int key)
{
	int i;
	int p;
	int aux_ind;
	float aux_val;
	
	if(val_key<heap->val[heap->m-1])
	{
		printf("New key is smaller than current key\n");
		exit(0);
	}
	
	heap->ind[heap->m-1]=key;
	heap->val[heap->m-1]=val_key;
	
	i=heap->m;
	p=parent(i);
	while(i>1 && heap->val[p-1]<heap->val[i-1])
	{
		aux_ind=heap->ind[i-1];
		heap->ind[i-1]=heap->ind[p-1];
		heap->ind[p-1]=aux_ind;
		
		aux_val=heap->val[i-1];
		heap->val[i-1]=heap->val[p-1];
		heap->val[p-1]=aux_val;
		
		i=p;
		p=parent(i);
	}
}

int heap_extract_max(struct binary_heap *heap)
{
	int imax;
	
	if(heap->m<1)
	{
		printf("heap underflow\n");
		exit(0);
	}
	
	imax=heap->ind[0];
	
	heap->ind[0]=heap->ind[heap->m-1];
	heap->val[0]=heap->val[heap->m-1];
	heap->m--;
	
	max_heapify(heap,1);
	
	return imax;
}

void max_heapify(struct binary_heap *heap,int i)
{
	int l;
	int r;
	int largest;
	int aux_ind;
	float aux_val;
	
	l=left(i);
	r=right(i);
	
	if(l<=heap->m && heap->val[l-1]>heap->val[i-1])
	{
		largest=l;
	}
	else
	{
		largest=i;
	}
	
	if(r<=heap->m && heap->val[r-1]>heap->val[largest-1])
	{
		largest=r;
	}
	
	if(largest!=i)
	{
		aux_ind=heap->ind[i-1];
		heap->ind[i-1]=heap->ind[largest-1];
		heap->ind[largest-1]=aux_ind;
		
		aux_val=heap->val[i-1];
		heap->val[i-1]=heap->val[largest-1];
		heap->val[largest-1]=aux_val;
		
		max_heapify(heap,largest);
	}
}

void build_max_heap(struct binary_heap *heap)
{
	int i;
	
	heap->m=heap->n;
	
	for(i=heap->n/2;i>0;i--)
	{
		max_heapify(heap,i);
	}
}

void heapsort_max(struct binary_heap *heap)
{
	int aux_ind;
	float aux_val;
	
	int i;
	
	build_max_heap(heap);
	
	for(i=heap->n;i>1;i--)
	{
		aux_ind=heap->ind[i-1];
		heap->ind[i-1]=heap->ind[0];
		heap->ind[0]=aux_ind;
		
		aux_val=heap->val[i-1];
		heap->val[i-1]=heap->val[0];
		heap->val[0]=aux_val;
		
		heap->m--;
		
		max_heapify(heap,1);
	}
}

double geodist(double lon1, double lat1, double lon2, double lat2, double r)
{
	double phi1;
	double phi2;
	double dphi;
	double dlbd;
	double a;
	double c;
	double dist;
	
	phi1=lat1*M_PI/180.0;
	phi2=lat2*M_PI/180.0;
	dphi=(lat2-lat1)*M_PI/180.0;
	dlbd=(lon2-lon1)*M_PI/180.0;
	
	a=sin(dphi/2.0)*sin(dphi/2.0)+cos(phi1)*cos(phi2)*sin(dlbd/2.0)*sin(dlbd/2.0);
	c=2.0*atan2(sqrt(a),sqrt(1-a));
	dist=r*c;
	
	return dist;
}

double sphetriare(double delta, double lon0, double lat0, double r)
{
    double are0;   
    double lon0a,lat0a;
    double lon0b,lat0b;
    double lon0c,lat0c;
    double lon0d,lat0d;
    double a,b,c,s,e;
    double are0a,are0b;
   
    lon0a=lon0;
    lat0a=lat0;
   
    lon0b=lon0+delta;
    lat0b=lat0-delta;
   
    lon0c=lon0;
    lat0c=lat0-delta;
   
    lon0d=lon0+delta;
    lat0d=lat0;
   
    c=geodist(lon0a,lat0a,lon0b,lat0b,r);
   
    b=geodist(lon0a,lat0a,lon0c,lat0c,r);
    a=geodist(lon0c,lat0c,lon0b,lat0b,r);
    s=(a/r+b/r+c/r)/2.;
   
    e=4*atan(sqrt(tan(s/2.)*tan((s-a/r)/2.)*tan((s-b/r)/2.)*tan((s-c/r)/2.)));
   
    are0a=e*r*r;
   
    b=geodist(lon0a,lat0a,lon0d,lat0d,r);
    a=geodist(lon0d,lat0d,lon0b,lat0b,r);
    s=(a/r+b/r+c/r)/2.;
   
    e=4*atan(sqrt(tan(s/2.)*tan((s-a/r)/2.)*tan((s-b/r)/2.)*tan((s-c/r)/2.)));
    are0b=e*r*r;
   
    are0=are0a+are0b;
   
    return are0;
}
